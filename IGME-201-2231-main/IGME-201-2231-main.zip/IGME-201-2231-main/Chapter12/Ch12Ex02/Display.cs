using System;

namespace Ch12Ex02
{
	/// <summary>
	/// Summary description for Display.
	/// </summary>
	public class Display
	{
		
         public void DisplayMessage(string message)
         {
            Console.WriteLine("Message arrived: {0}", message);
         }

	
	}
}
