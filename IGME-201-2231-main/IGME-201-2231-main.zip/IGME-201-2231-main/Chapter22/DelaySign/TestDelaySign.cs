using System;

public class TestDelaySign
{
  public static void Main ( )
  {
    DelayedSigning  s = new DelayedSigning ( ) ;
  }
}