To use the WebServiceSample example, you need to set up the WebServiceSample folder
as a virtual directory.


To do this, right-click on the folder, select Sharing, and from the Web Sharing tab choose 
Share this Folder. The default alias of WebServiceSample will be created for you. This will
do!

Have fun!
