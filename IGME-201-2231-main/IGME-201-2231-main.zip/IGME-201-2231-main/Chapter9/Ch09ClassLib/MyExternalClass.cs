using System;

namespace Ch09ClassLib
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
   public class MyExternalClass
   {
      public MyExternalClass()
      {
         //
         // TODO: Add constructor logic here
         //
      }
   }

}
