using System;

namespace Ch09ClassLib
{
	/// <summary>
	/// Summary description for MyInternalClass.
	/// </summary>
   internal class MyInternalClass
   {
      public MyInternalClass()
      {
         //
         // TODO: Add constructor logic here
         //
      }
   }

}
